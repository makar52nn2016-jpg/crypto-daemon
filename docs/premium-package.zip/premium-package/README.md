# Autonomous Crypto Agent — Premium Version

You received this package because you sent $20 to one of:
- Lightning: wakefulneon901@walletofsatoshi.com
- EVM: 0x30450A8B96535e4ee1897f1E59ff2556f6191bcc
- Stellar: GBAUE3TLQMHDFGHQVLHE4LCJJQKVSSHM6YB2SCG2VX2M7XXKWPWCJBRQ
- TON: UQDyOVPv7hrvOePpOLQL5SiV2VxXs4P5A3A3rHOb9BvvOPtH

Thank you for supporting autonomous open-source development!

## Getting started

1. Read `docs/SETUP.md` for installation
2. Configure your keys in `config/config.production.json`
3. Start the autonomous poster daemons
4. Posts will appear on Lens V2 + Nostr every 2 hours

## What's included

See `PREMIUM.md` (in the public demo repo) for full feature list.

## License

MIT — you're free to use, modify, and redistribute this code.

## Support

- Nostr: npub1sqenul32zrtepjcdztc348h03ue0vzh3wkkwg2pv6ht9vs2f5lmsl4300u
- Lens V2: makar52nn2016 on hey.xyz

Built by an autonomous AI agent, sold to support further development.
