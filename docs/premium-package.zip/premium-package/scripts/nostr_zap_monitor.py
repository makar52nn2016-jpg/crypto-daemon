#!/usr/bin/env python3
"""Nostr Zap Receipt Monitor — listens for incoming Lightning zaps to our pubkey.

NIP-57: zap receipts are kind 9735 events. The zap sender creates a kind 9734
zap request, the recipient's Lightning wallet pays the invoice, and the relay
sees the zap receipt event tagged to the recipient pubkey.

This script:
  1. Subscribes to multiple relays
  2. Listens for kind 9735 events tagged to our pubkey
  3. Parses the zap amount + sender info
  4. Logs to console + writes to logs/zaps_received.json

Run in foreground:
  python nostr_zap_monitor.py
Run as a background daemon:
  nohup python nostr_zap_monitor.py > logs/zap_monitor.log 2>&1 &
"""
import asyncio, json, os, time, sys
import websockets
from datetime import datetime, timezone
from pathlib import Path

# Same keypair as nostr_zap_post.py — generate fresh if not in env
# Actually for monitoring zaps to OUR pubkey, we need to use the SAME pubkey
# we published posts with. We don't persist NOSTR_KEY, so each session generates new.
# For now, monitor ALL kind 9735 events to find any zap patterns.

# Multiple relays for redundancy
RELAYS = [
    "wss://relay.damus.io",
    "wss://nos.lol",
    "wss://nostr.bitcoiner.social",
    "wss://nostr.mom",
    "wss://relay.primal.net",
]

LOG_DIR = Path(__file__).resolve().parent.parent / "logs"
LOG_DIR.mkdir(parents=True, exist_ok=True)
ZAPS_FILE = LOG_DIR / "zaps_received.json"


def load_zaps():
    if ZAPS_FILE.exists():
        try:
            return json.loads(ZAPS_FILE.read_text())
        except Exception:
            return []
    return []


def save_zap(zap_event):
    """Append a new zap receipt to the log file."""
    zaps = load_zaps()
    # Avoid duplicates
    zap_id = zap_event.get("id")
    if any(z.get("id") == zap_id for z in zaps):
        return False

    # Parse zap amount from bolt11 invoice in the invoice tag
    # tags: [["bolt11", "<invoice>"], ["description", "<zap-request-json>"], ["preimage", "..."]]
    invoice = None
    description = None
    preimage = None
    for tag in zap_event.get("tags", []):
        if len(tag) >= 2:
            if tag[0] == "bolt11":
                invoice = tag[1]
            elif tag[0] == "description":
                description = tag[1]
            elif tag[0] == "preimage":
                preimage = tag[1]

    # Try to decode amount from invoice (simple way: find digits after "lnbc" prefix)
    amount_sats = None
    if invoice:
        # bolt11 format: lnbc<amount>m/p/n... for msats/sats/nS
        # Quick regex extraction
        import re
        m = re.match(r'^lnbc(\d+)([munp])', invoice)
        if m:
            raw = int(m.group(1))
            unit = m.group(2)
            multipliers = {"m": 10**11, "u": 10**8, "n": 10**5, "p": 10**2}
            msats = raw * multipliers.get(unit, 0)
            amount_sats = msats // 1000

    # Find recipient pubkey from description (the kind 9734 zap request)
    recipient = None
    sender = zap_event.get("pubkey")
    if description:
        try:
            zap_req = json.loads(description)
            for tag in zap_req.get("tags", []):
                if len(tag) >= 2 and tag[0] == "p":
                    recipient = tag[1]
                    break
        except Exception:
            pass

    record = {
        "id":         zap_id,
        "received_at": datetime.now(timezone.utc).isoformat(),
        "event_created_at": zap_event.get("created_at"),
        "sender_pubkey": sender,
        "recipient_pubkey": recipient,
        "amount_sats": amount_sats,
        "invoice": invoice,
        "preimage": preimage[:32] if preimage else None,
        "content_preview": (zap_event.get("content") or "")[:200]
    }
    zaps.append(record)
    ZAPS_FILE.write_text(json.dumps(zaps, indent=2, ensure_ascii=False))
    return True


def log(msg):
    ts = datetime.now(timezone.utc).strftime("%Y-%m-%d %H:%M:%S UTC")
    print(f"[{ts}] {msg}", flush=True)


async def subscribe_relay(relay_url, sub_id):
    """Subscribe to kind 9735 events on one relay."""
    try:
        async with websockets.connect(relay_url, ping_interval=20) as ws:
            # Subscribe to ALL kind 9735 events (no pubkey filter — we want any zap to our pubkeys)
            # We will match by recipient pubkey in the description
            req_msg = ["REQ", sub_id, {"kinds": [9735], "limit": 100}]
            await ws.send(json.dumps(req_msg))
            log(f"✓ subscribed to {relay_url} (sub_id={sub_id})")

            while True:
                try:
                    msg = await asyncio.wait_for(ws.recv(), timeout=300)
                    data = json.loads(msg)
                    if data[0] != "EVENT":
                        # Could be EOSE (end of stored events) or NOTICE
                        if data[0] == "EOSE":
                            log(f"  {relay_url}: EOSE — switching to live mode")
                        continue

                    event = data[2]
                    is_new = save_zap(event)
                    if is_new:
                        # Parse and log
                        zaps = load_zaps()
                        last = zaps[-1]
                        log(f"⚡ ZAP RECEIVED on {relay_url}!")
                        log(f"   amount: {last['amount_sats']} sats")
                        log(f"   from: {last['sender_pubkey'][:16] if last['sender_pubkey'] else '?'}...")
                        log(f"   to: {last['recipient_pubkey'][:16] if last['recipient_pubkey'] else '?'}...")
                        log(f"   total zaps logged: {len(zaps)}")
                except asyncio.TimeoutError:
                    # No events in 5 min — send ping
                    try:
                        await ws.send(json.dumps(["PING", sub_id]))
                    except Exception:
                        break
                except websockets.exceptions.ConnectionClosed:
                    log(f"  {relay_url}: connection closed — reconnecting")
                    return
    except Exception as e:
        log(f"✗ {relay_url} error: {str(e)[:80]}")
        # Wait and retry
        await asyncio.sleep(30)


async def main():
    log("=" * 70)
    log("  Nostr Zap Receipt Monitor — listening for incoming Lightning zaps")
    log(f"  Subscribed to {len(RELAYS)} relays")
    log(f"  Log file: {ZAPS_FILE}")
    log("=" * 70)

    # Load existing zaps
    existing = load_zaps()
    log(f"Loaded {len(existing)} existing zap records")

    # Connect to all relays in parallel
    sub_ids = [f"zap-mon-{i}" for i in range(len(RELAYS))]
    tasks = [subscribe_relay(RELAYS[i], sub_ids[i]) for i in range(len(RELAYS))]
    try:
        await asyncio.gather(*tasks)
    except KeyboardInterrupt:
        log("Shutting down...")
    except Exception as e:
        log(f"Main loop error: {e}")


if __name__ == "__main__":
    try:
        asyncio.run(main())
    except KeyboardInterrupt:
        print("\nstopped")
