#!/bin/bash
# Payment monitor loop — runs payment_monitor.py every 30 minutes
LOG=/home/z/my-project/logs/payment_monitor.log
mkdir -p /home/z/my-project/logs
while true; do
    echo "=== $(date -u +%Y-%m-%dT%H:%M:%SZ) ===" >> $LOG
    cd /home/z/my-project/scripts
    python payment_monitor.py >> $LOG 2>&1
    sleep 1800  # 30 min
done
