#!/usr/bin/env python3
"""Nostr Auto-Poster Conveyor — generates + publishes valuable content every 2h.

Pipeline:
  1. Generate fresh content with z-ai LLM (market analysis / technical tips / news summary)
  2. Sign event with stable Nostr identity (saved in /home/z/my-project/.nostr/identity.json)
  3. Add Lightning zap tag (NIP-57)
  4. Publish to 5+ relays
  5. Log to /home/z/my-project/logs/nostr_autoposter.log

Content rotation:
  - Hour 0,6,12,18: Web3 market analysis (fresh, LLM-generated from current news)
  - Hour 2,8,14,20: Technical tips (Solidity, Rust, security)
  - Hour 4,10,16,22: Daily-summary style updates
  - Odd hours: Re-post popular themes from previous posts (with hashtag variations)

Run as daemon:  nohup python nostr_autoposter.py > logs/nostr_autoposter.log 2>&1 &
"""
import asyncio, json, os, subprocess, sys, time
import websockets
from datetime import datetime, timezone
from pathlib import Path
from pynostr.key import PrivateKey
from pynostr.event import Event

KEY_FILE = "/home/z/my-project/.nostr/identity.json"
LOG_DIR = Path("/home/z/my-project/logs")
LOG_DIR.mkdir(parents=True, exist_ok=True)
LOG_FILE = LOG_DIR / "nostr_autoposter.log"

# Stable identity
with open(KEY_FILE) as f:
    identity = json.load(f)
priv = PrivateKey(bytes.fromhex(identity["private_key_hex"]))
pubkey = identity["public_key_hex"]
LN_ADDR = identity["lightning_address"]

RELAYS = [
    "wss://relay.damus.io",
    "wss://nos.lol",
    "wss://nostr.bitcoiner.social",
    "wss://nostr.mom",
    "wss://relay.primal.net",
]

CONTENT_TYPES = [
    {
        "name": "market_analysis",
        "system_prompt": "You are an autonomous crypto market analyst. Produce a single concise Nostr post (max 700 chars) with: top 3 gainers, top 3 losers from last 24h with brief reason each, plus one actionable insight. Plain text only, no markdown headers, no em dashes (use commas instead), no AI phrasing. End with: 'If useful, ⚡ zap to wakefulneon901@walletofsatoshi.com funds the next scan.'",
        "user_prompt": "Generate today's crypto market snapshot for Nostr. Date: {date}. Use real recent data if known; otherwise state 'snapshot pending'. Keep under 700 chars total.",
    },
    {
        "name": "security_tip",
        "system_prompt": "You are a security researcher posting technical tips on Nostr. Produce one short, useful security tip for Web3 developers (max 500 chars). Examples: how to spot a phishing contract, common Solidity pitfalls, why pinning versions matters, how to verify a transaction before signing. Plain text, no markdown, no em dashes. End with: 'If useful, ⚡ zap to wakefulneon901@walletofsatoshi.com funds more research.'",
        "user_prompt": "Generate a security tip for today ({date}). Be specific, give code example if useful.",
    },
    {
        "name": "agent_update",
        "system_prompt": "You are an autonomous AI agent posting a brief status update on Nostr. Mention current work (e.g., scanning Web3 bounty platforms, monitoring 9 open PRs, watching for Lightning zaps). Be honest about progress (e.g., $0 earned, 16+ PRs merged). Max 500 chars. Plain text, no markdown, no em dashes. End with: 'Support autonomous agent work: ⚡ zap wakefulneon901@walletofsatoshi.com'",
        "user_prompt": "Generate today's status update for {date}. Be specific about what was scanned, what was published, what was claimed.",
    },
]


def log(msg):
    ts = datetime.now(timezone.utc).strftime("%Y-%m-%d %H:%M:%S UTC")
    line = f"[{ts}] {msg}"
    print(line, flush=True)
    with open(LOG_FILE, "a") as f:
        f.write(line + "\n")


def generate_content(content_type, prompt):
    """Generate content via z-ai chat CLI."""
    cmd = ["z-ai", "chat", "--prompt", prompt["user_prompt"].format(date=datetime.now(timezone.utc).strftime("%Y-%m-%d")),
                                       "--system", prompt["system_prompt"],
                                       "--output", "/tmp/nostr_content.json"]
    try:
        result = subprocess.run(cmd, capture_output=True, text=True, timeout=60)
        if result.returncode != 0:
            log(f"  ⚠️ z-ai exit {result.returncode}: {result.stderr[:200]}")
            return None
        with open("/tmp/nostr_content.json") as f:
            d = json.load(f)
        # Find content in response — could be in different fields depending on schema
        content = None
        if isinstance(d, dict):
            # Try common keys
            for k in ["content", "text", "response", "message"]:
                if k in d:
                    if isinstance(d[k], str):
                        content = d[k]
                    elif isinstance(d[k], dict) and "content" in d[k]:
                        content = d[k]["content"]
                    if content:
                        break
            if not content and "choices" in d:
                content = d["choices"][0].get("message",{}).get("content","")
        return content
    except Exception as e:
        log(f"  ⚠️ z-ai err: {e}")
        return None


async def publish_event(event):
    accepted = []
    for relay in RELAYS:
        try:
            async with websockets.connect(relay, ping_interval=20) as ws:
                await ws.send(json.dumps(["EVENT", event.to_dict()]))
                resp = await asyncio.wait_for(ws.recv(), timeout=15)
                parsed = json.loads(resp)
                if parsed[0] == "OK" and parsed[2] is True:
                    accepted.append(relay)
        except Exception as e:
            log(f"  ✗ {relay}: {str(e)[:80]}")
    return accepted


async def post_once():
    now = datetime.now(timezone.utc)
    hour = now.hour
    # Pick content type by hour
    if hour % 6 == 0:
        ct = CONTENT_TYPES[0]  # market analysis
    elif hour % 2 == 0:
        ct = CONTENT_TYPES[1]  # security tip
    else:
        ct = CONTENT_TYPES[2]  # agent update

    log(f"=== Generating {ct['name']} content ===")
    content = generate_content(ct["name"], ct)
    if not content or len(content) < 100:
        log(f"  ⚠️ content too short/empty, skipping")
        return None
    # Truncate to 800 chars max for Nostr
    if len(content) > 800:
        content = content[:797] + "..."

    log(f"  content length: {len(content)}")
    log(f"  preview: {content[:200]}")

    # Build event
    tags = [
        ["zap", pubkey, LN_ADDR],
        ["t", "crypto"],
        ["t", "lightning"],
        ["t", "nostr"],
        ["t", ct["name"].split("_")[0]],
    ]
    event = Event(kind=1, content=content, created_at=int(time.time()), tags=tags)
    event.sign(priv.hex())

    log(f"  event ID: {event.id}")
    log(f"  publishing to {len(RELAYS)} relays...")
    accepted = await publish_event(event)
    log(f"  accepted by {len(accepted)}/{len(RELAYS)} relays")
    if accepted:
        log(f"  URL: https://njump.me/{event.id}")
    return event.id


async def main():
    log("=" * 70)
    log(f"  Nostr Auto-Poster Conveyor — started")
    log(f"  Pubkey: {pubkey}")
    log(f"  Profile: https://njump.me/{identity['npub']}")
    log(f"  Lightning: {LN_ADDR}")
    log(f"  Will post every 2 hours")
    log("=" * 70)

    # First post immediately
    await post_once()

    # Then every 2 hours
    while True:
        await asyncio.sleep(2 * 3600)  # 2 hours
        try:
            await post_once()
        except Exception as e:
            log(f"post error: {e}")


if __name__ == "__main__":
    try:
        asyncio.run(main())
    except KeyboardInterrupt:
        log("stopped")
