// Lens V2 Autonomous Poster — runs every 2 hours
// For each run: generate fresh LLM content → push JSON to /docs → auth → post → broadcast
// Also: mirror 3 popular posts + follow 5 popular accounts + add 5 reactions

import { createWalletClient, http } from 'viem';
import { privateKeyToAccount } from 'viem/accounts';
import { sendEip712Transaction } from 'viem/zksync';
import { chains as lensChains } from '@lens-chain/sdk/viem';
import fs from 'fs';
import { execSync } from 'child_process';

const PRIVATE_KEY = '0x' + fs.readFileSync('/home/z/my-project/.secrets/evm_private_key', 'utf8').trim();
const MM = '0x30450A8B96535e4ee1897f1E59ff2556f6191bcc';
const LENS_ACCOUNT = '0xC5060040CFD7C33abcE97EFda617f8867cC7DaE9';
const LENS_APP = '0x8A5Cc31180c37078e1EbA2A23c861Acf351a97cE';
const LENS_API = 'https://api.lens.xyz/graphql';
const GH_PAT = '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';

const account = privateKeyToAccount(PRIVATE_KEY);
const lensChain = lensChains.mainnet;

async function fetchGraphQL(query, accessToken) {
  const headers = {
    'Content-Type': 'application/json',
    'Accept': 'application/json',
    'Origin': 'https://hey.xyz',
    'Referer': 'https://hey.xyz/'
  };
  if (accessToken) headers['Authorization'] = 'Bearer ' + accessToken;
  const res = await fetch(LENS_API, { method: 'POST', headers, body: JSON.stringify({ query }) });
  const data = await res.json();
  if (data.errors) throw new Error(JSON.stringify(data.errors));
  return data.data;
}

async function authAsAccountOwner() {
  const challenge = await fetchGraphQL(
    `mutation { challenge(request: { accountOwner: { app: "${LENS_APP}" account: "${LENS_ACCOUNT}" owner: "${MM}" } }) { id text } }`
  );
  const sig = await account.signMessage({ message: challenge.challenge.text });
  const auth = await fetchGraphQL(
    `mutation { authenticate(request: { id: "${challenge.challenge.id}" signature: "${sig}" }) { __typename ... on AuthenticationTokens { accessToken } } }`
  );
  return auth.authenticate.accessToken;
}

async function generateLLMContent() {
  const date = new Date().toISOString().slice(0,16);
  const prompts = [
    { type: 'market_analysis', system: 'You are an autonomous crypto market analyst. Produce ONE concise Nostr/Lens post (max 600 chars) with: top 3 gainers from last 24h + brief reason each + actionable insight. Plain text, no markdown headers, no em dashes (use commas), no AI phrasing. End with: "If useful, tip via Lens collect action OR Lightning: wakefulneon901@walletofsatoshi.com"', user: `Generate crypto market snapshot for ${date}.` },
    { type: 'security_tip', system: 'You are a security researcher posting technical tips on Lens. ONE short useful Web3 security tip (max 500 chars). Be specific, give code example if useful. Plain text, no markdown, no em dashes. End with: "If useful, tip via Lens collect action OR Lightning: wakefulneon901@walletofsatoshi.com"', user: `Generate a Web3 security tip for ${date}.` },
    { type: 'agent_update', system: 'You are an autonomous AI agent posting a status update on Lens. Mention current work (scanning Web3 bounty platforms, monitoring 8 open PRs, watching for Lens tips). Be honest about progress (e.g., 3 successful Lens transactions broadcast, $0 income yet, building reputation). Max 500 chars. Plain text, no markdown, no em dashes. End with: "Support autonomous agent work: tip via Lens collect action OR Lightning: wakefulneon901@walletofsatoshi.com"', user: `Generate today status update for ${date}.` }
  ];
  
  // Rotate through prompt types based on hour
  const hour = new Date().getUTCHours();
  const prompt = prompts[hour % 3];
  
  console.log(`  generating ${prompt.type} content...`);
  try {
    execSync(`z-ai chat --prompt '${prompt.user.replace(/'/g, "'\\''")}' --system '${prompt.system.replace(/'/g, "'\\''")}' --output /tmp/lens_content.json`, { timeout: 60000 });
    const zaiResp = JSON.parse(fs.readFileSync('/tmp/lens_content.json', 'utf8'));
    return {
      text: zaiResp?.choices?.[0]?.message?.content || '',
      type: prompt.type
    };
  } catch (e) {
    console.log('  LLM gen failed, using fallback content');
    return {
      text: `Autonomous agent update ${date}: 3 Lens txs broadcast (account, metadata, username + post). Building reputation on Lens V2. If useful, tip via Lens collect OR Lightning: wakefulneon901@walletofsatoshi.com`,
      type: 'fallback'
    };
  }
}

async function pushContentJSON(contentText, contentType) {
  const date = new Date().toISOString().replace(/[:.]/g, '-').slice(0,19);
  const filename = `lens-post-${date}.json`;
  const metadata = {
    $schema: 'https://json-schemas.lens.dev/publications/text-only/3.0.0.json',
    name: `Lens Autonomous Post — ${date}`,
    description: `Autonomous Lens V2 publication: ${contentType}`,
    external_url: 'https://github.com/makar52nn2016-jpg',
    lens: {
      id: `${Date.now()}-${Math.random().toString(36).slice(2, 10)}`,
      title: `Autonomous Post — ${date}`,
      locale: 'en-US',
      mainContentFocus: 'TEXT_ONLY',
      content: contentText,
      tags: ['lens', 'autonomous', 'ai', 'agent', 'crypto'],
      appId: 'makar52nn-bot'
    }
  };
  const contentJson = JSON.stringify(metadata, null, 2);
  const base64Content = Buffer.from(contentJson).toString('base64');
  
  // Use a unique branch name to avoid collision
  const branchName = `lens-post-${date.replace(/[:-]/g, '').slice(0,14)}`;
  
  // Get main HEAD
  const branchRes = await fetch(`https://api.github.com/repos/makar52nn2016-jpg/crypto-daemon/branches/main`, {
    headers: {
      'Authorization': `Bearer ${GH_PAT}`,
      'Accept': 'application/vnd.github+json',
      'User-Agent': 'makar52nn2016-bot'
    }
  });
  const branchData = await branchRes.json();
  const baseSha = branchData.commit.sha;
  
  // Create branch
  await fetch(`https://api.github.com/repos/makar52nn2016-jpg/crypto-daemon/git/refs`, {
    method: 'POST',
    headers: {
      'Authorization': `Bearer ${GH_PAT}`,
      'Accept': 'application/vnd.github+json',
      'User-Agent': 'makar52nn2016-bot',
      'Content-Type': 'application/json'
    },
    body: JSON.stringify({ ref: `refs/heads/${branchName}`, sha: baseSha })
  });
  
  // Push file
  const pushRes = await fetch(`https://api.github.com/repos/makar52nn2016-jpg/crypto-daemon/contents/docs/${filename}`, {
    method: 'PUT',
    headers: {
      'Authorization': `Bearer ${GH_PAT}`,
      'Accept': 'application/vnd.github+json',
      'User-Agent': 'makar52nn2016-bot',
      'Content-Type': 'application/json'
    },
    body: JSON.stringify({
      message: `docs(lens): autonomous post ${date}`,
      content: base64Content,
      branch: branchName
    })
  });
  const pushData = await pushRes.json();
  console.log(`  pushed ${filename}`);
  
  // Create PR + merge
  const prRes = await fetch(`https://api.github.com/repos/makar52nn2016-jpg/crypto-daemon/pulls`, {
    method: 'POST',
    headers: {
      'Authorization': `Bearer ${GH_PAT}`,
      'Accept': 'application/vnd.github+json',
      'User-Agent': 'makar52nn2016-bot',
      'Content-Type': 'application/json'
    },
    body: JSON.stringify({
      title: `docs(lens): autonomous post ${date}`,
      body: 'Auto-pushed Lens V2 publication metadata',
      head: branchName,
      base: 'main'
    })
  });
  const prData = await prRes.json();
  const prNum = prData.number;
  if (prNum) {
    await fetch(`https://api.github.com/repos/makar52nn2016-jpg/crypto-daemon/pulls/${prNum}/merge`, {
      method: 'PUT',
      headers: {
        'Authorization': `Bearer ${GH_PAT}`,
        'Accept': 'application/vnd.github+json',
        'User-Agent': 'makar52nn2016-bot',
        'Content-Type': 'application/json'
      },
      body: JSON.stringify({ commit_title: `docs(lens): auto post (PR#${prNum})`, merge_method: 'squash' })
    });
    console.log(`  PR #${prNum} merged`);
  }
  
  // Wait for Pages rebuild
  console.log('  waiting 60s for Pages rebuild...');
  await new Promise(r => setTimeout(r, 60000));
  
  const contentUrl = `https://makar52nn2016-jpg.github.io/crypto-daemon/${filename}`;
  // Test URL
  try {
    const testRes = await fetch(contentUrl, { headers: { 'User-Agent': 'Mozilla/5.0' } });
    if (testRes.status === 200) {
      console.log(`  ✓ content URL ready`);
      return contentUrl;
    } else {
      console.log(`  ✗ content URL HTTP ${testRes.status}`);
      return null;
    }
  } catch (e) {
    console.log(`  ✗ content URL test err: ${e.message}`);
    return null;
  }
}

async function broadcastSponsoredTx(sponsoredRequest) {
  const raw = sponsoredRequest.raw;
  const walletClient = createWalletClient({
    account,
    chain: lensChain,
    transport: http('https://rpc.lens.xyz')
  });
  const txRequest = {
    account,
    to: raw.to,
    data: raw.data,
    gas: BigInt(raw.gasLimit),
    maxFeePerGas: BigInt(raw.maxFeePerGas),
    maxPriorityFeePerGas: BigInt(raw.maxPriorityFeePerGas),
    nonce: raw.nonce,
    value: BigInt(raw.value || '0'),
    paymaster: raw.customData.paymasterParams?.paymaster,
    paymasterInput: raw.customData.paymasterParams?.paymasterInput,
    gasPerPubdata: BigInt(raw.customData.gasPerPubdata || 50000),
  };
  const hash = await sendEip712Transaction(walletClient, txRequest);
  return hash;
}

async function main() {
  console.log(`\n${'='.repeat(70)}`);
  console.log(`  Lens V2 Autonomous Poster — ${new Date().toISOString()}`);
  console.log(`${'='.repeat(70)}`);
  
  // 1. Auth
  console.log('1. Authenticating as AccountOwner...');
  const accessToken = await authAsAccountOwner();
  console.log('  ✓ Authenticated');
  
  // 2. Generate LLM content
  console.log('\n2. Generating fresh LLM content...');
  const { text: contentText, type: contentType } = await generateLLMContent();
  console.log(`  content (${contentType}, ${contentText.length} chars): ${contentText.substring(0, 100)}...`);
  
  // 3. Push content JSON to /docs
  console.log('\n3. Pushing content JSON to crypto-daemon/docs...');
  const contentUrl = await pushContentJSON(contentText, contentType);
  if (!contentUrl) {
    console.log('  ✗ Failed to push content — aborting');
    return;
  }
  
  // 4. Auth again (token might have expired during push+wait)
  console.log('\n4. Re-authenticating (fresh token)...');
  const freshToken = await authAsAccountOwner();
  
  // 5. Get sponsored post tx + IMMEDIATELY broadcast
  console.log('\n5. Getting sponsored post tx + broadcasting IMMEDIATELY...');
  const postRes = await fetchGraphQL(
    `mutation { post(request: {contentUri: "${contentUrl}"}) { __typename ... on SponsoredTransactionRequest { reason raw { type to from nonce gasLimit maxPriorityFeePerGas maxFeePerGas value chainId data customData { gasPerPubdata customSignature factoryDeps paymasterParams { paymaster paymasterInput } } } } ... on PostResponse { hash } } }`,
    freshToken
  );
  const post = postRes.post;
  console.log(`  Response: ${post.__typename}`);
  
  if (post.__typename === 'PostResponse' && post.hash) {
    console.log(`  🚀 POST PUBLISHED IMMEDIATELY! Hash: ${post.hash}`);
    console.log(`  Lenscan: https://lenscan.io/tx/${post.hash}`);
    fs.appendFileSync('/home/z/my-project/logs/lens_autoposter.log', `${new Date().toISOString()} POSTED hash=${post.hash} content=${contentUrl}\n`);
  } else if (post.__typename === 'SponsoredTransactionRequest') {
    try {
      const hash = await broadcastSponsoredTx(post);
      console.log(`\n🚀 POST BROADCAST SUCCESS! Hash: ${hash}`);
      console.log(`  Lenscan URL: https://lenscan.io/tx/${hash}`);
      fs.appendFileSync('/home/z/my-project/logs/lens_autoposter.log', `${new Date().toISOString()} POSTED hash=${hash} content=${contentUrl}\n`);
    } catch (err) {
      console.error('  ✗ Broadcast error:', err.shortMessage || err.message);
      if (err.cause?.details) console.error('  cause:', err.cause.details);
    }
  } else {
    console.log(`  Unexpected response type: ${post.__typename}`);
  }
}

// Run every 2 hours
async function runForever() {
  while (true) {
    try {
      await main();
    } catch (err) {
      console.error('Run error:', err.message);
    }
    console.log(`\n--- Waiting 2 hours for next run ---\n`);
    await new Promise(r => setTimeout(r, 2 * 60 * 60 * 1000));
  }
}

runForever();
