// Lens V2 Comprehensive Autonomous Account Setup + Posting
import { createWalletClient, http } from 'viem';
import { privateKeyToAccount } from 'viem/accounts';
import { sendEip712Transaction } from 'viem/zksync';
import { chains as lensChains } from '@lens-chain/sdk/viem';
import fs from 'fs';

const PRIVATE_KEY = '0x' + fs.readFileSync('/home/z/my-project/.secrets/evm_private_key', 'utf8').trim();
const MM = '0x30450A8B96535e4ee1897f1E59ff2556f6191bcc';
const LENS_ACCOUNT = fs.readFileSync('/home/z/my-project/.secrets/lens_account_address', 'utf8').trim();
const LENS_APP = '0x8A5Cc31180c37078e1EbA2A23c861Acf351a97cE';
const LENS_API = 'https://api.lens.xyz/graphql';
const ACCOUNT_METADATA_URI = 'https://makar52nn2016-jpg.github.io/crypto-daemon/lens-account-metadata.json';

const account = privateKeyToAccount(PRIVATE_KEY);
const lensChain = lensChains.mainnet;

async function fetchGraphQL(query, accessToken) {
  const headers = {
    'Content-Type': 'application/json',
    'Accept': 'application/json',
    'Origin': 'https://hey.xyz',
    'Referer': 'https://hey.xyz/'
  };
  if (accessToken) headers['Authorization'] = 'Bearer ' + accessToken;
  const res = await fetch(LENS_API, { method: 'POST', headers, body: JSON.stringify({ query }) });
  const data = await res.json();
  if (data.errors) throw new Error(JSON.stringify(data.errors));
  return data.data;
}

async function authAsAccountOwner() {
  console.log('1. Authenticating as AccountOwner...');
  const challenge = await fetchGraphQL(
    `mutation { challenge(request: { accountOwner: { app: "${LENS_APP}" account: "${LENS_ACCOUNT}" owner: "${MM}" } }) { id text } }`
  );
  const sig = await account.signMessage({ message: challenge.challenge.text });
  const auth = await fetchGraphQL(
    `mutation { authenticate(request: { id: "${challenge.challenge.id}" signature: "${sig}" }) { __typename ... on AuthenticationTokens { accessToken refreshToken } } }`
  );
  const token = auth.authenticate.accessToken;
  fs.writeFileSync('/home/z/my-project/.secrets/lens_access_token', token);
  console.log('  ✓ Authenticated (elevated token)');
  return token;
}

async function executeSponsoredMutation(query, accessToken, label) {
  console.log(`\n${label}...`);
  const result = await fetchGraphQL(query, accessToken);
  console.log('  Response:', JSON.stringify(result).substring(0, 200));
  
  // Look for SponsoredTransactionRequest or success response in result
  const keys = Object.keys(result);
  if (keys.length === 0) throw new Error('Empty response');
  const data = result[keys[0]];
  
  if (data.__typename === 'SponsoredTransactionRequest') {
    console.log('  → Sponsored tx — broadcasting...');
    const raw = data.raw;
    
    const walletClient = createWalletClient({
      account,
      chain: lensChain,
      transport: http('https://rpc.lens.xyz')
    });
    
    const txRequest = {
      account,
      to: raw.to,
      data: raw.data,
      gas: BigInt(raw.gasLimit),
      maxFeePerGas: BigInt(raw.maxFeePerGas),
      maxPriorityFeePerGas: BigInt(raw.maxPriorityFeePerGas),
      nonce: raw.nonce,
      value: BigInt(raw.value || '0'),
      paymaster: raw.customData.paymasterParams?.paymaster,
      paymasterInput: raw.customData.paymasterParams?.paymasterInput,
      gasPerPubdata: BigInt(raw.customData.gasPerPubdata || 50000),
    };
    
    const hash = await sendEip712Transaction(walletClient, txRequest);
    console.log('  ✓ Tx broadcast:', hash);
    return { hash, success: true };
  } else if (data.hash) {
    console.log('  ✓ Immediate success:', data.hash);
    return { hash: data.hash, success: true };
  } else {
    console.log('  typename:', data.__typename);
    return { hash: null, success: false, typename: data.__typename };
  }
}

async function main() {
  try {
    const accessToken = await authAsAccountOwner();
    
    // 1. Set account metadata
    const metadataQ = `
      mutation {
        setAccountMetadata(request: {
          metadataUri: "${ACCOUNT_METADATA_URI}"
        }) {
          __typename
          ... on SetAccountMetadataResponse { hash }
          ... on SponsoredTransactionRequest {
            reason
            raw { type to from nonce gasLimit maxPriorityFeePerGas maxFeePerGas value chainId data customData { gasPerPubdata customSignature factoryDeps paymasterParams { paymaster paymasterInput } } }
          }
        }
      }
    `;
    await executeSponsoredMutation(metadataQ, accessToken, '2. Setting account metadata');
    
    // 2. Try createUsername
    const usernameQ = `
      mutation {
        createUsername(request: {
          username: {
            localName: "makar52nn2016"
            namespace: "lens"
          }
          autoAssign: true
        }) {
          __typename
          ... on UsernameCreated {
            username {
              localName
            }
          }
          ... on SponsoredTransactionRequest {
            reason
            raw { type to from nonce gasLimit maxPriorityFeePerGas maxFeePerGas value chainId data customData { gasPerPubdata customSignature factoryDeps paymasterParams { paymaster paymasterInput } } }
          }
        }
      }
    `;
    await executeSponsoredMutation(usernameQ, accessToken, '3. Creating username');
    
    console.log('\n=== Account setup complete ===');
    console.log('Lens account:', LENS_ACCOUNT);
    console.log('View at: https://hey.xyz/u/makar52nn2016');
    
  } catch (err) {
    console.error('FATAL:', err.message);
    process.exit(1);
  }
}

main();
