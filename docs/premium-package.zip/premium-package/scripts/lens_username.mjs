// Create Lens username via sponsored tx
import { createWalletClient, http } from 'viem';
import { privateKeyToAccount } from 'viem/accounts';
import { sendEip712Transaction } from 'viem/zksync';
import { chains as lensChains } from '@lens-chain/sdk/viem';
import fs from 'fs';

const PRIVATE_KEY = '0x' + fs.readFileSync('/home/z/my-project/.secrets/evm_private_key', 'utf8').trim();
const MM = '0x30450A8B96535e4ee1897f1E59ff2556f6191bcc';
const LENS_ACCOUNT = '0xC5060040CFD7C33abcE97EFda617f8867cC7DaE9';
const LENS_APP = '0x8A5Cc31180c37078e1EbA2A23c861Acf351a97cE';
const LENS_API = 'https://api.lens.xyz/graphql';
const NAMESPACE = '0x201714eA176bee6fF1cffb21A0A7D067051B91fC';

const account = privateKeyToAccount(PRIVATE_KEY);
const lensChain = lensChains.mainnet;

async function fetchGraphQL(query, accessToken) {
  const headers = {
    'Content-Type': 'application/json',
    'Accept': 'application/json',
    'Origin': 'https://hey.xyz',
    'Referer': 'https://hey.xyz/',
  };
  if (accessToken) headers['Authorization'] = 'Bearer ' + accessToken;
  const res = await fetch(LENS_API, { method: 'POST', headers, body: JSON.stringify({ query }) });
  const data = await res.json();
  if (data.errors) throw new Error(JSON.stringify(data.errors));
  return data.data;
}

async function main() {
  // 1. Re-auth as AccountOwner (fresh token)
  console.log('1. Authenticating...');
  const challenge = await fetchGraphQL(
    `mutation { challenge(request: { accountOwner: { app: "${LENS_APP}" account: "${LENS_ACCOUNT}" owner: "${MM}" } }) { id text } }`
  );
  const sig = await account.signMessage({ message: challenge.challenge.text });
  const auth = await fetchGraphQL(
    `mutation { authenticate(request: { id: "${challenge.challenge.id}" signature: "${sig}" }) { __typename ... on AuthenticationTokens { accessToken } } }`
  );
  const accessToken = auth.authenticate.accessToken;
  fs.writeFileSync('/home/z/my-project/.secrets/lens_access_token', accessToken);
  console.log('  ✓ Authenticated');
  
  // 2. Create username (fresh sponsored tx — broadcast IMMEDIATELY)
  console.log('\n2. Creating username "makar52nn2016" (with namespace Lens)...');
  const usernameRes = await fetchGraphQL(
    `mutation {
      createUsername(request: {
        username: { localName: "makar52nn2016" namespace: "${NAMESPACE}" }
        autoAssign: true
      }) {
        __typename
        ... on CreateUsernameResponse { hash }
        ... on SponsoredTransactionRequest {
          reason
          raw { type to from nonce gasLimit maxPriorityFeePerGas maxFeePerGas value chainId data customData { gasPerPubdata customSignature factoryDeps paymasterParams { paymaster paymasterInput } } }
        }
      }
    }`,
    accessToken
  );
  const result = usernameRes.createUsername;
  console.log('  Response type:', result.__typename);
  
  if (result.__typename === 'CreateUsernameResponse' && result.hash) {
    console.log('  🚀 Username created immediately! Hash:', result.hash);
    return;
  }
  
  if (result.__typename === 'SponsoredTransactionRequest') {
    console.log('  Sponsored — broadcasting immediately...');
    const raw = result.raw;
    
    const walletClient = createWalletClient({
      account,
      chain: lensChain,
      transport: http('https://rpc.lens.xyz')
    });
    
    const txRequest = {
      account,
      to: raw.to,
      data: raw.data,
      gas: BigInt(raw.gasLimit),
      maxFeePerGas: BigInt(raw.maxFeePerGas),
      maxPriorityFeePerGas: BigInt(raw.maxPriorityFeePerGas),
      nonce: raw.nonce,
      value: BigInt(raw.value || '0'),
      paymaster: raw.customData.paymasterParams?.paymaster,
      paymasterInput: raw.customData.paymasterParams?.paymasterInput,
      gasPerPubdata: BigInt(raw.customData.gasPerPubdata || 50000),
    };
    
    try {
      const hash = await sendEip712Transaction(walletClient, txRequest);
      console.log('🚀 USERNAME TX BROADCAST! Hash:', hash);
      console.log('  Lenscan URL: https://lenscan.io/tx/' + hash);
      fs.writeFileSync('/home/z/my-project/.secrets/last_username_tx_hash', hash);
    } catch (err) {
      console.error('✗ Error:', err.shortMessage || err.message || err);
      if (err.details) console.error('  details:', err.details);
      if (err.cause?.details) console.error('  cause:', err.cause.details);
    }
  }
}

main().catch(e => {
  console.error('FATAL:', e.message);
  process.exit(1);
});
