#!/usr/bin/env python3
"""Universal Payment Monitor — watches all our wallets for incoming payments.

Covers:
  1. Base ETH + ERC-20 tokens (USDC, WETH, CBETH, DAI, AERO, etc.) via Alchemy RPC
  2. Stellar XLM + assets (USDC, etc.) via Horizon API
  3. Frantic agent status (earnedUsd, paidBounties, latestEvent)
  4. Nostr zap receipts (via nostr_zap_monitor.py running separately)

Logs to /home/z/my-project/logs/payment_monitor.log
Saves balance history to /home/z/my-project/logs/balance_history.json
Alerts (diff vs previous run) are appended to alert log.

Run in foreground:  python payment_monitor.py
Run in background:  nohup python payment_monitor.py > logs/payment_monitor.log 2>&1 &

Cron recommended: every 30 minutes.
"""
import json, os, sys, time, urllib.request, urllib.error
from datetime import datetime, timezone
from pathlib import Path

LOG_DIR = Path("/home/z/my-project/logs")
LOG_DIR.mkdir(parents=True, exist_ok=True)
HISTORY_FILE = LOG_DIR / "balance_history.json"
ALERTS_FILE = LOG_DIR / "payment_alerts.log"

# Wallets
MM = "0x30450A8B96535e4ee1897f1E59ff2556f6191bcc"  # MetaMask
STELLAR = "GBAUE3TLQMHDFGHQVLHE4LCJJQKVSSHM6YB2SCG2VX2M7XXKWPWCJBRQ"
FRANTIC_TOKEN = "fr_agent_df87636dea631f055428e7f9d327e680c7c548efffa87cca"
FRANTIC_KID = "agent-b94b60"

# Working RPC endpoints
ALCHEMY_BASE = "https://base-mainnet.g.alchemy.com/v2/demo"
ALCHEMY_ETH  = "https://eth-mainnet.g.alchemy.com/v2/demo"
STELLAR_HORIZON = "https://horizon.stellar.org"

# Tokens to monitor on Base
BASE_TOKENS = [
    ("USDC",    "0x833589fCD6eDb6E53424A94E26FaA41f8C8d99D9", 6),
    ("USDbC",   "0xd9aAEc86Bc652421181A8563DB508920A8E8E8D9", 6),
    ("WETH",    "0x4200000000000000000000000000000000000006", 18),
    ("CBETH",   "0x2Ae3F1Ec7F1F5072BdE9112e8Ed6e3dD35112434", 18),
    ("DAI",     "0x50c5725949A6C090E3D8De603d5F25E935720E5F", 18),
    ("AERO",    "0x940181a94A35A4569174538B638f8a578FeC2Fd7", 18),
    ("LUSD",    "0xC7B5aDBD4895803ed91C6413B5c357C51C2cAc29", 18),
]


def rpc_call(rpc_url, method, params):
    body = json.dumps({"jsonrpc":"2.0","method":method,"params":params,"id":1}).encode()
    req = urllib.request.Request(rpc_url, data=body, method="POST",
        headers={"Content-Type":"application/json"})
    try:
        with urllib.request.urlopen(req, timeout=15) as r:
            return json.loads(r.read())
    except Exception as e:
        return {"error": str(e)[:100]}


def check_evm_balances():
    """Check ETH + all ERC-20 balances on Base."""
    balances = {}
    # ETH on Base
    r = rpc_call(ALCHEMY_BASE, "eth_getBalance", [MM, "latest"])
    if "result" in r:
        balances["base_eth"] = int(r["result"], 16) / 10**18
    # ETH on Ethereum mainnet
    r = rpc_call(ALCHEMY_ETH, "eth_getBalance", [MM, "latest"])
    if "result" in r:
        balances["eth_mainnet"] = int(r["result"], 16) / 10**18
    # ERC-20 tokens on Base
    addr_padded = MM[2:].lower().zfill(64)
    for name, addr, decimals in BASE_TOKENS:
        data = "0x70a08231" + addr_padded
        r = rpc_call(ALCHEMY_BASE, "eth_call", [{"to":addr,"data":data}, "latest"])
        if "result" in r and r["result"] != "0x" and r["result"] != "0x0":
            try:
                bal = int(r["result"], 16)
                if bal > 0:
                    balances[f"base_{name.lower()}"] = bal / 10**decimals
            except Exception:
                pass
        time.sleep(0.2)  # be polite to Alchemy
    return balances


def check_stellar_balances():
    """Check XLM + all asset balances on Stellar."""
    balances = {}
    url = f"{STELLAR_HORIZON}/accounts/{STELLAR}"
    req = urllib.request.Request(url, headers={"Accept":"application/json"})
    try:
        with urllib.request.urlopen(req, timeout=15) as r:
            d = json.loads(r.read())
        for b in d.get("balances", []):
            if b.get("asset_type") == "native":
                balances["xlm"] = float(b.get("balance", 0))
            else:
                code = b.get("asset_code", "?")
                balances[f"stellar_{code.lower()}"] = float(b.get("balance", 0))
    except Exception as e:
        balances["stellar_error"] = str(e)[:100]
    return balances


def check_frantic_status():
    """Check Frantic agent status for any new events or earned USD."""
    url = f"https://gofrantic.com/v1/agents/{FRANTIC_KID}/status"
    req = urllib.request.Request(url, headers={
        "Authorization": f"Bearer {FRANTIC_TOKEN}",
        "Accept": "application/json",
        "User-Agent": "payment-monitor"
    })
    try:
        with urllib.request.urlopen(req, timeout=15) as r:
            d = json.loads(r.read())
        a = d.get("agent", {})
        latest = a.get("latestEvent", {})
        return {
            "frantic_earned_usd":  a.get("earnedUsd", 0),
            "frantic_paid_bounties": a.get("paidBounties", 0),
            "frantic_latest_event": latest.get("text", "")[:80],
            "frantic_latest_at":   latest.get("at", ""),
            "frantic_quality_score": a.get("quality", {}).get("latestScore", "?"),
        }
    except Exception as e:
        return {"frantic_error": str(e)[:100]}


def load_history():
    if HISTORY_FILE.exists():
        try:
            return json.loads(HISTORY_FILE.read_text())
        except Exception:
            return {}
    return {}


def save_history(history):
    HISTORY_FILE.write_text(json.dumps(history, indent=2, ensure_ascii=False))


def alert(message):
    """Write alert to log + print."""
    ts = datetime.now(timezone.utc).isoformat()
    line = f"[{ts}] {message}"
    print(line, flush=True)
    with open(ALERTS_FILE, "a") as f:
        f.write(line + "\n")


def main():
    now = datetime.now(timezone.utc).isoformat()
    print(f"\n{'=' * 70}", flush=True)
    print(f"  Payment Monitor — {now}", flush=True)
    print(f"{'=' * 70}", flush=True)

    current = {}
    current.update(check_evm_balances())
    current.update(check_stellar_balances())
    current.update(check_frantic_status())

    print("\nCurrent balances:")
    for k, v in current.items():
        print(f"  {k:30s}  {v}", flush=True)

    # Compare with previous run
    prev = load_history()
    changes = []
    for k, v in current.items():
        old = prev.get(k)
        if old is None:
            continue  # first run for this key, skip
        if isinstance(v, (int, float)) and isinstance(old, (int, float)):
            if v > old:
                changes.append((k, old, v, "INCREASED"))
            elif v < old:
                changes.append((k, old, v, "DECREASED"))
        elif v != old:
            changes.append((k, old, v, "CHANGED"))

    if changes:
        for k, old, new, direction in changes:
            alert(f"🚨 {direction}: {k}  {old} → {new}")
    else:
        print("\nNo changes since last run.", flush=True)

    # Save new history
    save_history(current)
    print(f"\n  saved to {HISTORY_FILE}", flush=True)
    print(f"  alerts log: {ALERTS_FILE}", flush=True)


if __name__ == "__main__":
    main()
