// Lens V2 E2E Autonomous Post — authenticates as AccountOwner, gets sponsored tx, signs, broadcasts
import { createWalletClient, http } from 'viem';
import { privateKeyToAccount } from 'viem/accounts';
import { sendEip712Transaction } from 'viem/zksync';
import { chains as lensChains } from '@lens-chain/sdk/viem';
import fs from 'fs';

const PRIVATE_KEY = '0x' + fs.readFileSync('/home/z/my-project/.secrets/evm_private_key', 'utf8').trim();
const MM = '0x30450A8B96535e4ee1897f1E59ff2556f6191bcc';
const LENS_ACCOUNT = '0xC5060040CFD7C33abcE97EFda617f8867cC7DaE9';
const LENS_APP = '0x8A5Cc31180c37078e1EbA2A23c861Acf351a97cE';
const LENS_API = 'https://api.lens.xyz/graphql';
const CONTENT_URI = 'https://makar52nn2016-jpg.github.io/crypto-daemon/lens-content.json';

const account = privateKeyToAccount(PRIVATE_KEY);
console.log('Account:', account.address);

const lensChain = lensChains.mainnet;
console.log('Chain:', lensChain.name, 'id:', lensChain.id);

async function fetchGraphQL(query, accessToken) {
  const headers = {
    'Content-Type': 'application/json',
    'Accept': 'application/json',
    'Origin': 'https://hey.xyz',
    'Referer': 'https://hey.xyz/'
  };
  if (accessToken) headers['Authorization'] = 'Bearer ' + accessToken;
  const res = await fetch(LENS_API, {
    method: 'POST',
    headers,
    body: JSON.stringify({ query })
  });
  const data = await res.json();
  if (data.errors) throw new Error(JSON.stringify(data.errors));
  return data.data;
}

async function main() {
  // 1. accountOwner challenge (after account creation, this gives us elevated permissions)
  console.log('\n1. Getting accountOwner challenge...');
  const challenge = await fetchGraphQL(
    `mutation { challenge(request: { accountOwner: { app: "${LENS_APP}" account: "${LENS_ACCOUNT}" owner: "${MM}" } }) { id text } }`
  );
  console.log('  Challenge ID:', challenge.challenge.id);
  
  console.log('2. Signing challenge...');
  const sig = await account.signMessage({ message: challenge.challenge.text });
  console.log('  Signature:', sig.substring(0, 80) + '...');
  
  console.log('3. Authenticating as accountOwner...');
  const auth = await fetchGraphQL(
    `mutation { authenticate(request: { id: "${challenge.challenge.id}" signature: "${sig}" }) { __typename ... on AuthenticationTokens { accessToken refreshToken } } }`
  );
  const accessToken = auth.authenticate.accessToken;
  fs.writeFileSync('/home/z/my-project/.secrets/lens_access_token', accessToken);
  console.log('  ✓ Got elevated access token');
  
  // 4. Get fresh sponsored transaction request from post mutation
  console.log('\n4. Calling post mutation (fresh sponsored tx)...');
  const post = await fetchGraphQL(
    `mutation { post(request: {contentUri: "${CONTENT_URI}"}) { __typename ... on SponsoredTransactionRequest { reason raw { type to from nonce gasLimit maxPriorityFeePerGas maxFeePerGas value chainId data customData { gasPerPubdata customSignature factoryDeps paymasterParams { paymaster paymasterInput } } } } ... on PostResponse { __typename hash } } }`,
    accessToken
  );
  const postResult = post.post;
  console.log('  Response type:', postResult.__typename);
  
  if (postResult.__typename === 'PostResponse' && postResult.hash) {
    console.log('\n🚀 POST CREATED IMMEDIATELY! Hash:', postResult.hash);
    console.log('  Lenscan URL: https://lenscan.io/tx/' + postResult.hash);
    return;
  }
  
  if (postResult.__typename !== 'SponsoredTransactionRequest') {
    throw new Error('Unexpected response type: ' + postResult.__typename);
  }
  
  // 5. Sign + broadcast IMMEDIATELY (before paymaster signature deadline passes)
  console.log('\n5. Broadcasting EIP-712 transaction immediately...');
  const raw = postResult.raw;
  console.log('  to:', raw.to);
  console.log('  nonce:', raw.nonce);
  console.log('  gasLimit:', raw.gasLimit);
  console.log('  paymaster:', raw.customData.paymasterParams?.paymaster);
  
  const walletClient = createWalletClient({
    account,
    chain: lensChain,
    transport: http('https://rpc.lens.xyz')
  });
  
  const txRequest = {
    account,
    to: raw.to,
    data: raw.data,
    gas: BigInt(raw.gasLimit),
    maxFeePerGas: BigInt(raw.maxFeePerGas),
    maxPriorityFeePerGas: BigInt(raw.maxPriorityFeePerGas),
    nonce: raw.nonce,
    value: BigInt(raw.value || '0'),
    paymaster: raw.customData.paymasterParams?.paymaster,
    paymasterInput: raw.customData.paymasterParams?.paymasterInput,
    gasPerPubdata: BigInt(raw.customData.gasPerPubdata || 50000),
  };
  
  try {
    const hash = await sendEip712Transaction(walletClient, txRequest);
    console.log('\n🚀 TRANSACTION BROADCAST SUCCESS!');
    console.log('  Hash:', hash);
    console.log('  Lenscan URL: https://lenscan.io/tx/' + hash);
    fs.writeFileSync('/home/z/my-project/.secrets/last_lens_tx_hash', hash);
  } catch (err) {
    console.error('✗ Error:', err.shortMessage || err.message || err);
    if (err.details) console.error('  details:', err.details);
    if (err.cause?.details) console.error('  cause:', err.cause.details);
    throw err;
  }
}

main().catch(e => {
  console.error('FATAL:', e.message);
  process.exit(1);
});
