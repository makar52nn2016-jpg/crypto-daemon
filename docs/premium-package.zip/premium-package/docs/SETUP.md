# Setup Guide

## Prerequisites
- Python 3.11+
- Node.js 18+
- GitHub account
- EVM wallet (MetaMask)
- Lightning wallet (Wallet of Satoshi / Alby)

## Installation

1. Clone this package
2. `cd scripts && npm install` (installs viem + @lens-chain/sdk)
3. `pip install eth-account pynostr websockets` (Python deps)
4. Install z-ai CLI: `npm install -g z-ai-web-dev-sdk`

## Configuration

1. Copy `config/config.example.json` to `config/config.production.json`
2. Fill in your wallet addresses, GitHub PAT, Alchemy key
3. Save your EVM private key to `~/.secrets/evm_private_key` (chmod 600)
4. Save Alchemy key to `~/.secrets/alchemy_api_key` (chmod 600)
5. Save GitHub PAT to env: `export GH_PAT=ghp_...`

## Lens V2 setup

1. Run `node scripts/lens_account_setup.mjs`
   - Creates your Lens V2 account (gasless)
   - Sets account metadata
   - Creates your username
2. Verify on https://hey.xyz/u/YOUR_USERNAME

## Start autonomous poster

```bash
# Lens V2 autoposter (every 2h)
nohup node scripts/lens_autoposter.mjs > logs/lens.log 2>&1 &

# Nostr autoposter (every 2h)
nohup python scripts/nostr_autoposter.py > logs/nostr.log 2>&1 &

# Payment monitor (every 30 min)
nohup bash scripts/payment_monitor_loop.sh > logs/payment.log 2>&1 &

# Zap monitor (real-time)
nohup python scripts/nostr_zap_monitor.py > logs/zap.log 2>&1 &
```

## Verify it's working

- Check `logs/lens.log` — should show "POSTED hash=0x..."
- Visit https://lenscan.io/tx/<hash> to verify on-chain
- Visit https://hey.xyz/u/<your_username> to see your post

## Support

DM `npub1sqenul32zrtepjcdztc348h03ue0vzh3wkkwg2pv6ht9vs2f5lmsl4300u` on Nostr for help.
